#!/bin/bash

./radar_passes.sh "very_busy" $@

