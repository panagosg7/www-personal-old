#!/bin/bash

./radar_passes.sh "const_prop" $@
