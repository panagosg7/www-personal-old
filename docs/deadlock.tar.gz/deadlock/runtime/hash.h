extern uint32_t SuperFastHash (const char * data, int len, uint32_t hash);
