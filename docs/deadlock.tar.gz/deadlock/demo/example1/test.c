#include <stdio.h> //printf
#include <stdlib.h> //exit
#include <pthread.h> //pthread_create,pthread_join,pthread_mutex_lock,pthread_mutex_unlock
#include <unistd.h> //usleep

//type declarations
struct group {
	pthread_mutex_t * a;
	pthread_mutex_t * b;
	int v;
};

void *monitor (void *);
void *thread(void *);
struct group *init();

//global variables
volatile int progress;
pthread_mutex_t gl1;
pthread_mutex_t gl2;
struct group gl_group;

//functions
int main()
{
	pthread_t tid[3];
	struct group * g;
	printf("Program started\n");
	g = init();
	pthread_create( &tid[0], NULL, thread, g);
	pthread_create( &tid[1], NULL, thread, g);
   usleep(50);
   pthread_create(&tid[2], NULL, monitor, NULL);
	pthread_join( tid[0], NULL);
	pthread_join( tid[1], NULL); 
  return 0;
}

struct group *init() 
{	struct group * g;
	g = &gl_group;
	g->a = &gl1;
	g->b = &gl2;
	g->v = 5;
	return g;
}

void *thread(void *p)
{
 struct group * g = (struct group *) p;
 int i ;
  progress = 1;  
	for (i = 0; i < 10000; i++){	
    progress = 1;  
    if (g->v % 2 == 0) {
			pthread_mutex_lock( g->a );
			pthread_mutex_lock( g->b );
			g->v ++;
			usleep(10);
			pthread_mutex_unlock( g->b );
			pthread_mutex_unlock( g->a );		
		}
		else {
			pthread_mutex_lock( g->b );
			pthread_mutex_lock( g->a );
			g->v ++;
			pthread_mutex_unlock( g->a );
			pthread_mutex_unlock( g->b );		
		}
	}
	return (void *) 0;
}

void nsleep (long nsec)
{
  struct timespec sleepTime, remainingSleepTime;
  sleepTime.tv_sec = 0;
  sleepTime.tv_nsec = nsec;
  while (nanosleep(&sleepTime, &remainingSleepTime) != 0)
    sleepTime = remainingSleepTime;
}
#define MONITOR_TIME 100000000 // 0.1 sec
void *monitor (void *p)
{
  while (1) {
    progress = 0;
    nsleep(MONITOR_TIME);
    if (!progress) {
      fprintf(stderr, "deadlock!");
      exit(1);
    }
  }    
}
/*	g = (struct group *) malloc(sizeof(struct group));
	g->a = (pthread_mutex_t * ) malloc(sizeof(pthread_mutex_t));
	g->b = (pthread_mutex_t * ) malloc(sizeof(pthread_mutex_t));  
	g = &gl_group; //(struct group *) malloc(sizeof(struct group));
 //(pthread_mutex_t * ) malloc(sizeof(pthread_mutex_t));
	 //(pthread_mutex_t * ) malloc(sizeof(pthread_mutex_t));*/
