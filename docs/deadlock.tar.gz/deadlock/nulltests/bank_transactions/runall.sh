#!/bin/sh
./run.sh 50 1000
#./process.sh
