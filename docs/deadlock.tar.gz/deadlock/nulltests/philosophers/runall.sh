#!/bin/sh

METHOD=f

function run () {
    echo "$1"
    ./run.sh 10 2
    mkdir $1
    mv OUTPUT.* $1/
}

function foo () {
    ./gen_philosophers.py $1 > philosophers.c
    make clean
    make

    run `printf "RUN-$METHOD-%03d" $1`
}

foo 5
foo 10
foo 15
foo 31
foo 63
foo 127
foo 255
