#!/usr/bin/env python

import sys

try:
    max = int(sys.argv[1])
except:
    print >> sys.stderr, "Usage: %s <number-of-philosophers>" % sys.argv[0]
    exit(1)

print '''\
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/time.h>
#include <inttypes.h>

int EATING_TIME   = 10000;   // up to 10 usec
int SLEEPING_TIME = 100000;  // up to 100 usec
int MONITOR_TIME  = 1000000; // 1000 usec

void nsleep (long nsec)
{
  struct timespec sleepTime, remainingSleepTime;
  sleepTime.tv_sec = 0;
  sleepTime.tv_nsec = nsec;
  while (nanosleep(&sleepTime, &remainingSleepTime) != 0)
    sleepTime = remainingSleepTime;
}

#define rsleep(nsec)                  \\
  ({                                  \\
    uint32_t r;                       \\
    random_r(&buf, (int32_t *) &r);   \\
    r %= nsec;                        \\
    nsleep(r);                        \\
    r;                                \\
  })
'''

print "#define MAX %d" % max

print '''\
unsigned long int eat_count[MAX];
enum { SLEEPING, WAITING_1, WAITING_2, EATING } status[MAX];

unsigned int futex_count[MAX];
unsigned long usec[MAX];
unsigned int futex_neq[MAX];
unsigned int futex_woken[MAX];
unsigned int futex_spurious[MAX];
unsigned int futex_timeout[MAX];
unsigned int futex_minusone[MAX];
unsigned int futex_other[MAX];
__thread unsigned int tid = 0;

volatile int progress;

#define PRNG_BUFSZ 256
#define MAGIC_SEED 0x42420000

#define MAKE_STICK(n) pthread_mutex_t stick_##n = PTHREAD_MUTEX_INITIALIZER;
#define MAKE_PHILOSOPHER(curr, succ)                                    \\
  void * philosopher_##curr (void * arg)                                \\
  {                                                                     \\
    struct random_data buf;                                             \\
    static char statebuf[PRNG_BUFSZ];                                   \\
    memset( &buf, 0, sizeof( struct random_data ) );                    \\
    initstate_r(MAGIC_SEED + curr, statebuf, PRNG_BUFSZ, &buf);         \\
    tid = curr;                                                         \\
    futex_count[tid] = 0;                                               \\
    futex_neq[tid] = 0;                                                 \\
    futex_woken[tid] = 0;                                               \\
    futex_other[tid] = 0;                                               \\
    futex_spurious[tid] = 0;                                            \\
    futex_timeout[tid] = 0;                                             \\
    futex_minusone[tid] = 0;                                            \\
    usec[tid] =  0;                                                     \\
    status[curr] = SLEEPING;                                            \\
    for (;;) {                                                          \\
      rsleep(SLEEPING_TIME);                                            \\
      status[curr] = WAITING_1;                                         \\
      pthread_mutex_lock(&stick_##curr);                                \\
      status[curr] = WAITING_2;                                         \\
      pthread_mutex_lock(&stick_##succ);                                \\
      status[curr] = EATING;                                            \\
      eat_count[curr]++;                                                \\
      progress = 1;                                                     \\
      assert(status[(curr+MAX-1)%MAX] != EATING);                       \\
      assert(status[(curr+1)%MAX] != EATING);                           \\
      rsleep(EATING_TIME);                                              \\
      assert(status[(curr+MAX-1)%MAX] != EATING);                       \\
      assert(status[(curr+1)%MAX] != EATING);                           \\
      status[curr] = SLEEPING;                                          \\
      pthread_mutex_unlock(&stick_##curr);                              \\
      pthread_mutex_unlock(&stick_##succ);                              \\
    }                                                                   \\
    return NULL;                                                        \\
  }
'''

for i in range(max):
    print "MAKE_STICK(%d)" % i

print ""

for i in range(max):
    print "MAKE_PHILOSOPHER(%d, %d)" % (i, (i+1) % max)

print '''
pthread_t main_tid, thread[MAX];
int deadlock;

void results ()
{
  if (pthread_self() != main_tid) pthread_exit(NULL);

  unsigned long int sum = 0;
  int i;
  int avg_futex = 0;
'''
print "  for (i = 0; i < %d; i++) {" % max
print '''\
    printf("Philosopher %d ate %lu times).\\n", i, eat_count[i]);
    sum += eat_count[i];
    avg_futex += futex_count[i];
    int avg = 0 ;
    int futex_i = futex_count[i];
    int futex_w = futex_woken[i];
    int futex_n = futex_neq[i];
    int futex_s = futex_spurious[i];
    int futex_t = futex_timeout[i];
    int futex_o = futex_other[i];
    int futex_m = futex_minusone[i];
    int usec_i = usec[i];
    if( futex_i && usec_i){
      avg = usec_i / (long) futex_i;
    }
    #ifdef PRINT_STUFF
    printf("[%d] futex_count=%d futex_w=%d futex_n=%d futex_s=%d futex_t=%d futex_m=%d futex_o=%d total usecs=%d average usecs=%d\\n",i,
             futex_i,futex_w,futex_n,futex_s,futex_t,futex_m,futex_o,usec_i,(int) avg);
   #endif
   }
#ifdef PRINT_STUFF
  printf("total futex=%d average futex=%d\\n",avg_futex, avg_futex/i);
#endif
  printf("%sSum = %lu\\n", deadlock ? "[deadlock] " : "", sum);
  exit(deadlock);
}
'''

print '''
int main (int argc, char *argv[])
{
  unsigned long int count, max;
  int confirmed;
  int i;

  if (argc == 2)
    max = strtoul(argv[1], NULL, 10);
  else
    max = 1;

  main_tid = pthread_self();
'''

for i in range(max):
    print "  pthread_create(&thread[%d], NULL, philosopher_%d, NULL);" % (i, i)

print '''
  deadlock = 0;

  struct sigaction act;
  act.sa_handler = &results;
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  sigaction(SIGALRM, &act, NULL);
  alarm(max);

  for (count = 0; ; count++) {
#ifdef DEBUG
    fprintf(stderr, "%lu\\r", count);
#endif
    progress = 0;
    nsleep(MONITOR_TIME);
    if (!progress) {
      printf("Apparent deadlock at count = %lu,", count);
      confirmed = 1;\
'''
print "      for (i = 0; i < %d; i++)" % max
print '''\
        switch (status[i]) {
        case SLEEPING:
          printf(" %d(s)", i);
          confirmed = 0;
          break;
        case WAITING_1:
          printf(" %d(w1)", i);
          confirmed = 0;
          break;
        case WAITING_2:
          printf(" %d(w2)", i);
          break;
        case EATING:
          printf(" %d(e)", i);
          confirmed = 0;
          break;
        }
      if (confirmed) {
        printf(" confirmed!\\n");
        deadlock = 1;
        results();
      }
      else
        printf(" false alarm...\\n");
    }
  }
  // will never come here
  return 0;
}'''
