#!/bin/sh

vanilla=`grep Sum OUTPUT.vanilla | grep -v deadlock | awk '\
  BEGIN          { total = 0; count = 0; } \
  /Sum = [0-9]+/ { total += $3; count++; } \
  END            { printf "%0.2f", (total / count); }'`

printf "vanilla:\t$vanilla\n"

modified=`grep Sum OUTPUT.modified | grep -v deadlock | awk '\
  BEGIN          { total = 0; count = 0; } \
  /Sum = [0-9]+/ { total += $3; count++; } \
  END            { printf "%0.2f", (total / count); }'`

printf "modified:\t$modified\n"

overhead=`printf "($vanilla - $modified) / $vanilla * 100\n" | bc -l`

printf "overhead:\t%0.2f%%\n" $overhead
