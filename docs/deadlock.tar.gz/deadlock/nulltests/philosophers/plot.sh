set title 'Philosopher Workload' # graph title
set xlabel 'Number of philosophers' 
set ylabel 'Total number of times the philosophers ate (in millions)' 
set key right bottom
set style line 1 lw 2 pt 2
set style line 2 lw 2 pt 4

plot RESULTS1 using 1:($2/1000000) with linespoints ls 1 \
     title 'Original C program', \
     RESULTS2 using 1:($2/1000000) with linespoints ls 2 \
     title 'Instrumented C program'
set terminal postscript eps color lw 1 "CMU Serif" 15
#set terminal png         # gnuplot recommends setting terminal before output
set output "output.eps"  # The output filename; to be set after setting
          # terminal
replot
