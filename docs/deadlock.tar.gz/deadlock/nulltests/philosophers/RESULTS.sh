#!/bin/tcsh

rm -f RESULTS.txt
touch RESULTS.txt

foreach d ( RUN-* )
  echo $d >> RESULTS.txt
  (cd $d; ../process.sh >> ../RESULTS.txt)
end
