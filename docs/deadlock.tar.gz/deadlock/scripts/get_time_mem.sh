grep "\(Elapsed time \)\|\(Top heap \)" $1
