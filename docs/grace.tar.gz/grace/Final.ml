open Printf
open Symbol
open Types
open Identifier 
open Quad
open PrintTools
  

let takenumber f = 
	match f.entry_info with
		|ENTRY_function function_info -> function_info.function_panagiotis
		| _ -> -1


let rec printstack s = 
match s with 
| x::xs -> printf "|%s|" (id_name (x.entry_id)) ; printstack xs
| [] -> printf "\n"


let cout = 
try
	let rec check_args i = 
		if Sys.argv.(i) = "-f" then stdout
		else check_args (i+1)
	in check_args 2
with  Invalid_argument ("index out of bounds") -> begin
	let start = try String.rindex  Sys.argv.(1)  '/' with Not_found -> 0 in
	let stop = String.rindex  Sys.argv.(1)  '.'  in
	let name = String.sub Sys.argv.(1) (start+1) (stop-start-1) in
	open_out (String.concat "" ["tmp/"; name; ".asm"]);  
(*	open_out "tmp/output.asm";*)
	
end

let stack = ref []	(* ������ �� ��� ����������� ��� �������� ����� �� ������ scope *)
let curr_struc_unit = ref ""

let extrn = ref (Hashtbl.create 12)
let strs = ref []
let str_n = ref 1
let str_num = ref 0

let create_hashtable_ size init =
	let tbl = Hashtbl.create size in
	List.iter (fun (key, data) -> Hashtbl.add tbl key data) init;
	tbl
let oper_table =
    create_hashtable_ 16 [(PLUS, "+" ); (MINUS, "-" ); (DIV, "/" ); (MUL, "*" ); (MOD, "%"); (EQ , "=" ); (DIFF , "<>" ); (LESS , "<" ); 
	(GREATER , ">" ); (ELESS , "<=" ); (EGREATER , ">=" ); (JUMP, "jump");(ARRAY, "array");(GIVE, ":=");(PAR, "par");(CALL, "call");
	(RETURN, "ret"); (UNIT, "unit"); (ENDU, "endu"); (NOTHING, "-") ]
let sym_table =
    create_hashtable_ 16 [('n', 10 ); ('t', 9 );('r', 13 );('0', 0); ('\\', 92); ('\'', 39);]


(* __________________________________________________PROSWRINES SYNARTISEIS DEBUGGING________________________________________________________ *)
(* __________________________________________________________________________________________________________________________________________ *)

let rec pretty_type typ =
  match typ with
  | TYPE_none ->
      printf  "<undefined>\n"
  | TYPE_int ->
      printf "int\n"
  | TYPE_byte ->
      printf "byte\n"
  | TYPE_index t ->
      printf "index of ";
		pretty_type t
  | TYPE_array (et, sz) ->
      pretty_type et;
      if sz > 0 then
        printf  " [%d]\n" sz
      else
        printf " []\n"
  | TYPE_proc ->
      printf "proc\n"

(* __________________________________________________VOITHITIKES SYNARTISEIS_________________________________________________________________ *)
(* __________________________________________________________________________________________________________________________________________ *)


let label z = 
	fprintf cout "@%d:\n" z

let getAR a =		(* to a einai Quad.arg *)
	let n_a = match a with 
				| Entry a_entry -> a_entry.entry_scope.sco_nesting 
				| _ -> 0 (*error*)
	in
(* to trexon ypoprogramma vrisketai stin kefali tis domis stack pou exoume orisei sto Parser.ml *)
	let n_curr = match !stack with
	|	[] -> 0
	| head :: _ ->  head.entry_scope.sco_nesting in
	begin
		fprintf cout "\t\tmov\tsi, word ptr[bp+4]\t\t\t;from_getAR\n";
		let n = n_curr - n_a -1 in
		begin
		for i=1 to n do
			fprintf cout "\t\tmov\tsi, word ptr[si+4]\t\t\t;from_getAR\n"
		done;
		()
		end
	end
	 

let updateAL x =	(* x: kaloumeni domiki monada *)
	let n_p = !currentScope.sco_nesting - 1 in  (*kalousa - ???*)
	let n_x = x.entry_scope.sco_nesting in
	begin
	if n_p < n_x or n_x = 0 then		(*to n_x = 1 anaferetai stis synartiseis pou orizoume emeis sti main*)
		fprintf cout "\t\tpush\tbp\t\t\t\t;from_update\n"
	else if n_p = n_x then
		fprintf cout "\t\tpush\tword ptr[bp+4]\t\t\t;from_update\n"
	else 
	begin
		fprintf cout "\t\tmov\tsi, word ptr[bp+4]\t\t\t;from_update\n";
		let n = n_p - n_x -1 in
		begin
		for i=1 to n do
			fprintf cout "\t\tmov\tsi, word ptr[si+4]\t\t\t;from_update\n"
		done;
		fprintf cout "\t\tpush\tword ptr[si+4]\t\t\t;from_update\n";
		()
		end
	end
	end
let rec load r a = 
	match a with
	| Integ	n -> fprintf cout "\t\tmov\t%s, %d\t\t\t\t\t\t;from_load\n" r n
	| Chara	c -> fprintf cout "\t\tmov\t%s, %d\t\t\t\t\t\t;from_load\n" r (int_of_char c)

	| Entry	e -> 
		begin
		let n_a = e.entry_scope.sco_nesting in
			let (a_size, offset, a_val_ref) = match e.entry_info with		
					| ENTRY_variable v_info -> (v_info.variable_type, v_info.variable_offset, PASS_BY_VALUE (*dummy*)) 
					| ENTRY_parameter p_info -> (p_info.parameter_type, p_info.parameter_offset, p_info.parameter_mode)
					| ENTRY_temporary t_info -> (t_info.temporary_type, t_info.temporary_offset, PASS_BY_VALUE (*dummy*)) 
					| _ -> (TYPE_none, 0, PASS_BY_VALUE (*dummy*))
			in
			let size = 				
				match a_size with 
					| TYPE_int -> "word"
					| TYPE_byte -> "byte"
					| TYPE_array (_,_) -> "word"
					| TYPE_index _ -> "word"				
					| _ -> "error_l"
			in
			let r1 =	if size = "byte" then begin
								match r with
								| "ax"->"al"
								| "dx" -> "dl"
								| _ -> r

								end
						else r
			in
			begin

				if n_a  = !currentScope.sco_nesting (*n_curr*) then	(*topiki ontotita*)
					match a_val_ref with
					| PASS_BY_VALUE -> 
						begin
							if offset < 0 then
								fprintf cout "\t\tmov\t%s, %s ptr [bp%d]\t\t\t;from_load1\n" r1 size offset
							else 
								fprintf cout "\t\tmov\t%s, %s ptr [bp+%d]\t\t\t;from_load1\n" r1 size offset
						end
					| _ -> 
						begin
							fprintf cout "\t\tmov\tsi, word ptr [bp+%d]\t\t\t;from_load2\n" offset;
							fprintf cout "\t\tmov\t%s, %s ptr [si]\t\t\t;from_load2\n" r1 size
						end	
				
				else				 		(*mi topiki ontotita*)
					match a_val_ref with
					| PASS_BY_VALUE -> 
						begin
							getAR a;		
							if offset < 0 then (*print -number*)
								fprintf cout "\t\tmov\t%s, %s ptr [si%d]\t\t\t;from_load3(changed)\n" r1 size offset							
							else 
								fprintf cout "\t\tmov\t%s, %s ptr [si+%d]\t\t\t;from_load3(changed)\n" r1 size offset							
						end
					| _ -> (*kat anafora*)
						begin
							getAR a;
							fprintf cout "\t\tmov\tsi, word ptr [si+%d]\t\t\t;from_load4\n" offset;
							fprintf cout "\t\tmov\t%s, %s ptr [si]\t\t\t;from_load4\n" r1 size
						end	
			end
		end
	| Index x -> 
		begin
			load "di" x;
			let size = match getType_ x with
									| TYPE_byte -> "byte"
									| TYPE_int -> "word"
									| TYPE_array (_,_)-> "word"
									| TYPE_index TYPE_int -> "word"
									| TYPE_index TYPE_byte -> "byte"								
									| _ -> "error"
			in
			let r1 =	if size = "byte" then begin
								match r with
								| "ax"->"al"
								| "dx" -> "dl"
								| _ -> r

								end
						else r
			in
			fprintf cout "\t\tmov\t%s, %s ptr [di]\t\t\t;from_load5\n" r1 size
		end
	| _-> fprintf cout ";error\t\t\tfrom_load\n"				
							


let store r a = 		(* r (register) is a string, a is a Quad.arg *)
	match a with
	| Entry	e -> 
		begin
	
		let n_a = e.entry_scope.sco_nesting in
			let (a_size, offset, a_val_ref) = match e.entry_info with		
					| ENTRY_variable v_info -> (v_info.variable_type, v_info.variable_offset, PASS_BY_VALUE (*dummy*)) 
					| ENTRY_parameter p_info -> (p_info.parameter_type, p_info.parameter_offset, p_info.parameter_mode)
					| ENTRY_temporary t_info -> (t_info.temporary_type, t_info.temporary_offset, PASS_BY_VALUE (*dummy*)) 
					| _ -> (TYPE_none, 0, PASS_BY_VALUE (*dummy*))
			in
			let size = 				
				match a_size with 
					| TYPE_int -> "word"
					| TYPE_byte -> "byte"
					| TYPE_array (_,_) -> "word"
					| TYPE_index _ -> "word"				
					| _ -> "error"
			in
			let r1 =	if size = "byte" then begin
								match r with
								| "ax"->"al"
								| "dx" -> "dl"
								| _ -> r

								end
						else r
			in
			begin
				if n_a = !currentScope.sco_nesting  then	(*topiki ontotita*)
					match a_val_ref with
					| PASS_BY_VALUE -> 
						if offset < 0 then
							fprintf cout "\t\tmov\t%s ptr [bp%d], %s\t\t\t;from_store\n" size offset r1
						else 
							fprintf cout "\t\tmov\t%s ptr [bp+%d], %s\t\t\t;from_store\n" size offset r1
					| _ -> 
						begin
							fprintf cout "\t\tmov\tsi, word ptr [bp+%d]\t\t\t;from_store\n" offset;
							fprintf cout "\t\tmov\t%s ptr [si], %s\t\t\t;from_store\n" size r1
						end	

				else				 		(*mi topiki ontotita*)
					match a_val_ref with
					| PASS_BY_VALUE -> 
						begin
							getAR a;		
							if offset < 0 then
								fprintf cout "\t\tmov\t%s ptr [si%d], %s\t\t\t;from_store\n" size offset r1
							else
								fprintf cout "\t\tmov\t%s ptr [si+%d], %s\t\t\t;from_store\n" size offset r1
						end
					| _ -> 
						begin
							getAR a;
							fprintf cout "\t\tmov\tsi, word ptr [si+%d]\t\t\t;from_store\n" offset;
							fprintf cout "\t\tmov\t%s ptr [si], %s\t\t\t;from_store\n" size r1
						end	
			end
		end
	| Index x -> 
		begin
			load "di" x;

			let size = match getType_ x with
									| TYPE_int -> "word"
									| TYPE_byte -> "byte"
									| TYPE_array(_, _) -> "word"					
									| TYPE_index TYPE_int -> "word"
									| TYPE_index TYPE_byte -> "byte"								
									| _ -> "error(in Store)"
			in
			let r1 =	if size = "byte" then begin
								match r with
								| "ax"->"al"
								| "dx" -> "dl"
								| _ -> r
								end
						else r
			in
			fprintf cout "\t\tmov\t%s ptr [di], %s\t\t\t;from_store\n" size r1
		end
	| RETARG ->
		
		let size = match r with		
		"al" -> "byte"
		| "cl" -> "byte"
		| _ -> "word"
			
		in
		begin 
			
			fprintf cout "\t\tmov\tsi, word ptr [bp+6]\t\t\t;from_store\n";
			fprintf cout "\t\tmov\t%s ptr [si], %s\t\t\t;from_store\n" size r
		end
	
	| _-> fprintf cout "error\t\t\t;from_store\n"		

let rec find_size a_size = 
	match a_size with 
	| TYPE_byte -> "byte"
	| TYPE_int -> "word"
	| TYPE_array(typ,_) -> find_size typ
	| _ -> "error"


let loadAddr r a = 
	match a with
	| Str s -> fprintf cout "\t\tlea\t%s, byte ptr %s\t\t\t\t\t\t;from_loadAddr\n" r s
	
	| Entry	e -> 
		begin
		
		let n_a = e.entry_scope.sco_nesting in
			let (a_size, offset, a_val_ref) = match e.entry_info with		
					| ENTRY_variable v_info -> (v_info.variable_type, v_info.variable_offset, PASS_BY_VALUE (*dummy*)) (*den tha einai metavliti*)
					| ENTRY_parameter p_info -> (p_info.parameter_type, p_info.parameter_offset, p_info.parameter_mode)
					| ENTRY_temporary t_info -> (t_info.temporary_type, t_info.temporary_offset, PASS_BY_VALUE (*dummy*))
					| _ -> (TYPE_none, 0, PASS_BY_VALUE (*dummy*))
			in
			let size = find_size a_size				
				
			in
			begin
				if n_a  = !currentScope.sco_nesting (*n_curr*) then	(*topiki ontotita*)
					match a_val_ref with
					| PASS_BY_VALUE -> 
						begin
							if offset < 0 then
								fprintf cout "\t\tlea\t%s, %s ptr [bp%d]\t\t\t;from_loadAddr-1\n" r size offset
							else 
								fprintf cout "\t\tmov\t%s, %s ptr [bp+%d]\t\t\t;from_loadAddr-1\n" r size offset
						end
					| _ -> 
						begin
							if offset < 0 then (*elegxos isws na mi xreiazetai*)
								fprintf cout "\t\tmov\t%s, word ptr [bp%d]\t\t\t;from_loadAddr-2\n" r offset
							else 
								fprintf cout "\t\tmov\t%s, word ptr [bp+%d]\t\t\t;from_loadAddr-2\n" r offset;
						end	
				else				 		(*mi topiki ontotita*)
					match a_val_ref with
					| PASS_BY_VALUE -> 
						begin
							getAR a;		
							if offset < 0 then 
								fprintf cout "\t\tlea\t%s, %s ptr [si%d]\t\t\t;from_loadAddr-3\n" r size offset							
							else 
								fprintf cout "\t\tlea\t%s, %s ptr [si+%d]\t\t\t;from_loadAddr-3\n" r size offset							
						end
					| _ -> 
						begin
							getAR a;
							fprintf cout "\t\tmov\t%s, word ptr [si+%d]\t\t\t;from_loadAddr-4\n" r offset
						end	
			end
		end
	| Index x -> load r x
	| _-> fprintf cout ";error\t\t\tfrom_load\n"		


let name struc_unit num = 
	if num < 12 then  fprintf cout "_%s" struc_unit
	 else  fprintf cout "_%s_%d" struc_unit num

let endof struc_unit num = 
	fprintf cout "@%s_%d:" struc_unit num


let getParamSize e = 
	
	match e.entry_info with
	| ENTRY_function f (*f = function_info*)-> 
		let plist = f.function_paramlist in
		let sot t =
		match t with
			| TYPE_int            -> 2
			| TYPE_byte           -> 1
			| _                   -> 0
		in
		let ei b = match b.entry_info with
		| ENTRY_parameter pi -> 
				begin
				match pi.parameter_mode with
				| PASS_BY_VALUE ->  sot pi.parameter_type
				| PASS_BY_REFERENCE ->  2
				end
		| _ -> -1
		in
			List.fold_left (fun a b -> a+ ei b) 0 plist
		
	| _ -> ignore (fprintf cout ";error\t\t\tfrom getParamSize\n") ; 0


(* prints the quad over assembly lines *)
let  auxPrintQuad (n, op,x,y,z) =
	let printN n = fprintf cout "\n; %d:\t" n in 
	let printOp o = fprintf cout "%s" (Hashtbl.find oper_table o) in
	let rec printArg a = 
		match a with
		Entry e -> 
			begin
			let s = id_name e.entry_id in
			if (String.length s) < 30 then Printf.fprintf cout "%s" s
			else Printf.fprintf cout "%s" (String.concat "" [(String.sub s 0 27) ; "..."])
		
			end
		| Integ n -> fprintf cout "%d" n
		| Chara c -> fprintf cout "%d" (int_of_char c) 
		| EMPTY -> fprintf cout "-" 
		| Label l -> fprintf cout "%d" l
		| Adress p -> fprintf cout "{" ; printArg p;  fprintf cout "}"
		| Index i -> fprintf cout "["; printArg i;  fprintf cout "]"
		| PMode PASS_BY_VALUE -> fprintf cout "V"
		| PMode PASS_BY_REFERENCE -> fprintf cout "R"
		| Str s -> fprintf cout "%s" s
		| RET ->fprintf cout "RET"
		| RETARG ->fprintf cout "$$"
		| _ ->  fprintf cout "error" (* should not be printed *) in
	printN n ; printOp op; fprintf cout ", ";  printArg x; fprintf cout ", "; printArg y; fprintf cout ", "; printArg z


(* ______________________________________________TELOS VOITHTIKWN SYNARTISEWN________________________________________________________________ *)
(* __________________________________________________________________________________________________________________________________________ *)
		


let quad_code (numQuad, op, x, y, z) = 
begin	
	
	auxPrintQuad (numQuad, op, x, y, z); fprintf cout "\n"; label numQuad;
	match op with
	| GIVE -> 
			begin				
				let register = match sizeOfType (getType_ x) with
									| 1 -> "al"
									| 2 -> "ax"
									| _ -> "error"
				in
				load register x;
				store register z
			end	
	| ARRAY ->
	begin
	match x with
	| Str st -> 		
		begin
			load "ax" y;
			incr str_num;
			strs :=   !strs @ [st];
			let s1 = string_of_int !str_num  in
			loadAddr "di" (Str (String.concat "" ["@str_"; s1]));			
			fprintf cout "\t\tadd\tdi, ax\n";
			fprintf cout "\t\tmov\tcl, byte ptr[di]\n";
			store "cl" z;
		end

	| _ ->
			begin
				load "ax" y;
				let (size, n) = match getType_ x with 
					| TYPE_array( t , n ) -> (sizeOfType t , n)
					| TYPE_index TYPE_array( t , n ) -> (sizeOfType t, n)
					| _ -> (0, 0)
				in
					fprintf cout "\t\tmov\tcx, %d\t\t\t;from array\n" size;			
				fprintf cout "\t\timul\tcx\n";
				loadAddr "cx" x;
				fprintf cout "\t\tadd\tax, cx\n";
				store "ax" z
			end
	end
	| PLUS ->
			begin
				load "ax" x;
				load "dx" y;
				fprintf cout "\t\tadd\tax, dx\n";
				store "ax" z;	
			end
	| MINUS ->
		begin
			match y with 
			| EMPTY ->
				begin
					load "ax" (Integ 0);
					load "dx" x;
					fprintf cout "\t\tsub\tax, dx\n";
					store "ax" z;	
				end
			| _ ->
				begin
					load "ax" x;
					load "dx" y;
					fprintf cout "\t\tsub\tax, dx\n";
					store "ax" z;	
				end
		end
	| MUL ->
			begin
				load "ax" x;
				load "cx" y;
				fprintf cout "\t\timul\tcx\n";
				store "ax" z;	
			end
	| DIV ->
			begin
				load "ax" x;
				fprintf cout "\t\tcwd\n";
				load "cx" y;
				fprintf cout "\t\tidiv\tcx\n";
				store "ax" z;	
			end
	| MOD ->
			begin
				load "ax" x;
				fprintf cout "\t\tcwd\n";
				load "cx" y;
				fprintf cout "\t\tidiv\tcx\n";
				store "dx" z;	
			end
	| EQ | DIFF | LESS | GREATER | ELESS | EGREATER ->
			begin
				load "ax" x;
				load "dx" y;

 				let compare = match getType_ x with
				| TYPE_byte | TYPE_index TYPE_byte -> fprintf cout "\t\tcmp\tal,dl\n"
				| TYPE_int  | TYPE_array(_, _) | TYPE_index TYPE_int -> fprintf cout "\t\tcmp\tax,dx\n"					
				| _ -> fprintf cout "error(in compare)"
				in compare; 
				let instr = match op with
										| EQ -> "je"
										| DIFF -> "jne"
										| LESS -> "jl"
										| GREATER -> "jg"
										| ELESS -> "jle"
										| EGREATER-> "jge" 
										| _ -> "error"
				in
					let address = match z with
											| Label n -> n
											| _ -> -1 (*error*)
					in
						fprintf cout "\t\t%s\t@%d\n" instr address;
			end
	| UNIT ->
		begin
			let fun_name = match x with 
									| Str s -> s
									| _ -> "error"
			in
			begin
				name fun_name  (takenumber (List.hd !stack));
					

				fprintf cout "\t\tproc\tnear\n";
				fprintf cout "\t\tpush\tbp\n";
				fprintf cout "\t\tmov\tbp, sp\n";
				fprintf cout "\t\tsub\tsp,%d\n" (-(!currentScope.sco_negofs));
				curr_struc_unit:=fun_name
			end
		end
	| ENDU ->
		begin
			let fun_name = match x with 
									| Str s -> s
									| _ -> "error"
			in
			begin
				endof fun_name (*(!currentScope.sco_nesting - 1)*) (takenumber (List.hd !stack));
				fprintf cout "\t\tmov\tsp, bp\n";
				fprintf cout "\t\tpop\tbp\n";
				fprintf cout "\t\tret\n";
				name fun_name (*(!currentScope.sco_nesting - 1)*) (takenumber (List.hd !stack));
				fprintf cout "\t\tendp\n"
			end
		end
	| CALL -> 
		begin

			match z with 
				| Str s -> let e = lookupEntry (id_make s) LOOKUP_ALL_SCOPES false in
					let kind = match e.entry_info with
						| ENTRY_function f-> f.function_result 
						| _ -> fprintf cout "\t\terror\n" ; TYPE_none
					in 
(*				changed 		*)
					let periergo = match e.entry_info with
					| ENTRY_function f-> f.function_panagiotis
					| _ -> begin fprintf cout "\t\tperiergo error\n"  ; -1 end
					in

					let size = getParamSize e
					in
					begin
			
						if e.entry_scope.sco_nesting = 0 then (*we have found call to extrn function*)
							begin
								let fname = id_name e.entry_id in
									try Hashtbl.find !extrn fname
									with Not_found -> Hashtbl.add !extrn fname ();
							end;
						if kind=TYPE_proc (* procedure *) then fprintf cout "\t\tsub sp,2\n";
						updateAL e;
						fprintf cout "\t\tcall\tnear ptr ";
						name s (*e.entry_scope.sco_nesting*) periergo;
						fprintf cout "\t;-----\n";
						fprintf cout "\t\tadd\tsp, %d\n" (size+4)
					end
				| _ -> fprintf cout "\t\terror\n";
			end

	| RETURN ->	(* changed *)
			let e = lookupEntry (id_make !curr_struc_unit) LOOKUP_ALL_SCOPES false in
			let periergo = match e.entry_info with
					| ENTRY_function f-> f.function_panagiotis
					| _ -> begin fprintf cout "\t\terror\n"  ; -1 end
			in
				fprintf cout "\t\tjmp\t@%s_%d" !curr_struc_unit (*(!currentScope.sco_nesting -1 )*) periergo

	| PAR -> 
		begin
			match (y, getType_ x) with 
			| (PMode PASS_BY_VALUE, TYPE_int) -> load "ax" x; fprintf cout "\t\tpush\tax\n";
 			| (PMode PASS_BY_VALUE, TYPE_index _) -> load "ax" x; fprintf cout "\t\tpush\tax\n"; 
			| (PMode PASS_BY_VALUE, TYPE_byte) ->	load "al" x; 
																fprintf cout "\t\tsub\tsp, 1\n";
																fprintf cout "\t\tmov\tsi, sp\n";
																fprintf cout "\t\tmov\tbyte ptr [si], al\n"
			| (PMode PASS_BY_VALUE, _) -> fprintf cout "error: invalid par by value\n"
			| (RET, _) -> loadAddr "si" x; fprintf cout "\t\tpush\tsi\n";
			| (PMode PASS_BY_REFERENCE, _) -> 
					begin
						match x with 
						| Str s ->
							begin incr str_num;
							strs :=   !strs @ [s];
							let s1 = string_of_int !str_num  in
								loadAddr "si" (Str (String.concat "" ["@str_"; s1])); 
							
							fprintf cout "\t\tpush\tsi\n"
							end

						| _ -> 
							loadAddr "si" x;
							fprintf cout "\t\tpush\tsi\n"
					end
			| (_, _) -> fprintf cout "error: invalid par\n"
		end

	| JUMP -> 
		begin
			let lab = match z with 
					| Label i -> i
					| _ -> -1 (*error value*)
			
			in
				fprintf cout "\t\tjmp\t@%d\n" lab
		end
	| _ -> fprintf cout "\n"
(* **************************************** *)
	
end

let xseg s = 
	begin  		
		let fname = "writeString" in
		try Hashtbl.find !extrn fname
		with Not_found -> Hashtbl.add !extrn fname ();

		
		Printf.fprintf cout "xseg\t\tsegment\tpublic 'code'\n";
		Printf.fprintf cout "\t\t\tassume\tcs:xseg, ds:xseg, ss:xseg\n";
		Printf.fprintf cout "\t\t\torg\t100h\n\n";
		Printf.fprintf cout "main\t\tproc\tnear\n";			 
		Printf.fprintf cout "\t\t\tcall\tnear ptr _%s_12\n" s; 
		Printf.fprintf cout "\t\t\tmov\tax, 4C00h\n";
		Printf.fprintf cout "\t\t\tint\t21h\n";
		Printf.fprintf cout "main\t\tendp\n\n";
	end



let rec print_st s ssl op i  = 
		if i = 0 then 
			begin		
				fprintf cout "@str_%d\t\tdb\t" !str_n;				
				if i = ssl then  fprintf cout "\t\t0\n"
					else  print_st s ssl op (i+1)
			end
  		else if (i = ssl ) then 
		begin
		if op then fprintf cout "\'\n\t\t\t\tdb\t0\n"
			else   fprintf cout "\t\t0\n"
		end
		else 
			if s.[i] = '\\' then  
				begin
					if op then fprintf cout "\'\n\t\tdb\t";
					fprintf cout "%d\n\t\tdb\t" (Hashtbl.find sym_table s.[(i+1)]); 			
					print_st s ssl false (i+2); 
				end
			else 	
				begin
					if op then  fprintf cout"%c" s.[i]
					else fprintf cout"\'%c" s.[i];		
					print_st s ssl true (i+1);
				end 
	
	 
let print_str s =
	let l = String.length s in
		begin 
				print_st s (l-1) false  0 ; 
				fprintf cout "\n" ;
				str_n := !str_n +1
		end

let  print_strings () = 
	fprintf cout "\n\n;strings' declaration\n";
	(ignore) (List.map (print_str) !strs);
	fprintf cout "\nxseg\t\t\tends\n\t\t\t\tend\tmain\n"
	
let print_extern () = 
	Printf.fprintf cout "\n\n;extrn declaration\n";
	
	Hashtbl.iter	(fun x y-> Printf.fprintf cout "\t\t\textrn\t_%s : proc\n" x) !extrn 
