open Printf
open Symbol
open Types
open Identifier 

type boole = Value of bool
and fal = False of int list
and tr = True of int list
and nex = Next of int list
and nq = NextQ of int
and op = PLUS | MINUS | DIV | MOD | MUL | EQ | DIFF | LESS | GREATER | ELESS | EGREATER | JUMP | ARRAY | GIVE | PAR |CALL | RETURN | UNIT | ENDU | NOTHING
and arg = Entry of Symbol.entry | Integ of int | Chara of char | Str of string | EMPTY | BLANK | Error_arg 
		| Cond of  fal * tr * nq |Stmt of nex * nq | Block of nex  | Label of int | Index of arg | Adress of arg 
		| PMode of pass_mode | RET | RETARG (*$$*)
and r_l =  L_val of arg | R_val of arg | RL_PROC

 let create_hashtable_ size init =
    let tbl = Hashtbl.create size in
    List.iter (fun (key, data) -> Hashtbl.add tbl key data) init;
    tbl


let oper_table =
    create_hashtable_ 16 [(PLUS, "+" ); (MINUS, "-" ); (DIV, "/" ); (MUL, "*" ); (MOD, "%"); (EQ , "=" ); (DIFF , "<>" ); (LESS , "<" ); 
	(GREATER , ">" ); (ELESS , "<=" ); (EGREATER , ">=" ); (JUMP, "jump");(ARRAY, "array");(GIVE, ":=");(PAR, "par");(CALL, "call");
	(RETURN, "ret"); (UNIT, "unit"); (ENDU, "endu"); (NOTHING, "-") ; ]


let numQuad = ref 0
let listQuad = ref []
let listPar = ref []

let strings = ref []
let externs = ref []

let cint = 
try
	let rec check_args i = 
		if Sys.argv.(i) = "-i" then stdout
		else check_args (i+1)
	in check_args 2
with  Invalid_argument ("index out of bounds") -> 
begin
	let start = try String.rindex  Sys.argv.(1)  '/' with Not_found -> 0 in
	let stop = String.rindex  Sys.argv.(1)  '.'  in
	let name = String.sub Sys.argv.(1) (start+1) (stop-start-1) in
	open_out (String.concat "" ["tmp/"; name; ".imm"]);
(*	open_out "tmp/output.imm";*)
end 


let rec getType_ e = 
	match e with
	Entry en ->
		begin
			match en.entry_info with
				ENTRY_none -> TYPE_none
            | ENTRY_variable variable_info -> variable_info.variable_type
            | ENTRY_function function_info -> function_info.function_result
            | ENTRY_parameter parameter_info -> parameter_info.parameter_type
            | ENTRY_temporary temporary_info -> temporary_info.temporary_type 
		end
	| Integ n -> TYPE_int
	| Chara c -> TYPE_byte
	| Str st -> TYPE_array (TYPE_byte, (String.length st) +1)
	| Adress p -> TYPE_array ((getType_ p), 0)
	| Index e -> getType_ e		
	| _ -> TYPE_none



(*takes r_l and gives typ*)
let getType e = 
	match e with
	R_val l -> getType_ l
	| L_val l -> getType_ l
	| RL_PROC -> TYPE_proc


(* takes r_l and gives arg *)	
let getArg e = 
	match e with 
	R_val l ->  l
	| L_val l -> l
	| RL_PROC -> Error_arg

(*takes r_l and gives entry*)	
(*
let getEntry rl = 
	let ar = getArg rl in
	match ar with 
	| Entry e -> e
*)	

(* outputs the intermediate code in inter.im *)
let  printQuad (n, op,x,y,z) =
	let printN n = Printf.fprintf cint "%d" n in (*changed recently*)
	let printOp o = Printf.fprintf cint "%s" (Hashtbl.find oper_table o) in
	let rec printArg a = 
		match a with
		Entry e -> Printf.fprintf cint "%s" (id_name e.entry_id)
		| Integ n -> Printf.fprintf cint "%d" n
		| Chara c -> Printf.fprintf cint "%d" (int_of_char c)  
		| EMPTY -> Printf.fprintf cint "-" 
		| Label l -> Printf.fprintf cint "%d" l 
		| Adress p -> Printf.fprintf cint "{";  printArg p; Printf.fprintf cint "}" 
		| Index i -> Printf.fprintf cint "[" ;  printArg i ; Printf.fprintf cint "]"
		| PMode PASS_BY_VALUE ->  Printf.fprintf cint "V"
		| PMode PASS_BY_REFERENCE -> Printf.fprintf cint "R"
		| Str s -> Printf.fprintf cint "%s" s
		| RET -> Printf.fprintf cint "RET"
		| RETARG -> Printf.fprintf cint "$$"
		| _ ->  Printf.fprintf cint "error" (*must not print this*) in
	let final (n, op,x,y,z)=
	 printN n ;Printf.fprintf cint ": " ; printOp op ; Printf.fprintf cint ", " ;
	 printArg x ; Printf.fprintf cint ", " ; printArg y  ;  Printf.fprintf cint ", " ; printArg z; Printf.fprintf cint "\n" 
	in final (n, op,x,y,z)

let printQuads ()=
	(ignore) (List.map printQuad !listQuad)
	
	

let genQuad op x y z =	
	listQuad := (List.append !listQuad [(!numQuad, op, x, y, z)]);	
	incr numQuad; ()

let nextQuad () = !numQuad


(*takes int list and int where int label *)
let backpatch (l, z) = 
	let f z l (xo, yo, zo, wo, un)  =  
		if (un == BLANK && List.mem xo l ) then (xo, yo, zo, wo, Label z) else (xo, yo, zo, wo, un)
	in 
	listQuad := List.map  (f z l ) !listQuad; ()

(* takes r_l and gives pass_mode *)
let paramMode x =
	match x.entry_info with
	|  ENTRY_parameter parameter_info -> parameter_info.parameter_mode
	| _ -> PASS_BY_VALUE (*should be never matched here*)
	

let boolean n (x, y, z,w, t) = (x=n)


(* elegxei an i teleutaia tetrada einai RETURN (ret) kai tote tin antikathista me endu
	alliws proxwra stin epomeni tin opoia thetei endu *)
let rec endu name lista =
	match lista with
	[] -> []
	| [(n ,op, x, y, z)] -> 
		begin
			if op=RETURN then [(n, ENDU, (Str name), EMPTY, EMPTY)] 
			else begin incr numQuad  ; [(n ,op, x, y, z);  (n+1, ENDU, (Str name), EMPTY, EMPTY)] end
		end
	| (x::xs) -> x :: (endu name xs) 	 
		

(*takes int list list*)
let rec merge l = 
	match l with
	[] -> []
	| [lh; lt] -> List.append lh lt
	| h::tail -> List.append h ( merge tail )



let makeList (x) = [x]

let emptyList () = []
