open Identifier
open Types
open Symbol

let openBasicScope() = 
initSymbolTable 256;
openScope();
(*  I/O*)
let f = newFunction (id_make "writeString") false in
let p = newParameter (id_make "_s") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in

ignore (p); 
endFunctionHeader f TYPE_proc ; 

let f = newFunction (id_make "writeInteger") false in
let p = newParameter (id_make "_n") TYPE_int PASS_BY_VALUE f false in

ignore (p); 
endFunctionHeader f TYPE_proc ; 


let f = newFunction (id_make "writeChar") false in
let p = newParameter (id_make "_c") TYPE_byte PASS_BY_VALUE f false in

ignore (p); 
endFunctionHeader f TYPE_proc ; 

let f = newFunction (id_make "readInteger") false in
endFunctionHeader f TYPE_int ; 


let f = newFunction (id_make "readChar") false in
endFunctionHeader f TYPE_byte;


let f = newFunction (id_make "readString") false in
let p1 = newParameter (id_make "_n") TYPE_int PASS_BY_VALUE f false in
let p2 = newParameter (id_make "_s") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in

ignore (p1); ignore (p2); 
endFunctionHeader f TYPE_proc ; 


(*casting*)
let f = newFunction (id_make "ascii") false in
let p = newParameter (id_make "_c") TYPE_byte PASS_BY_VALUE f false in

ignore (p); 
endFunctionHeader f TYPE_int ; 

let f = newFunction (id_make "chr") false in
let p = newParameter (id_make "_n") TYPE_int PASS_BY_VALUE f false in

ignore (p); 
endFunctionHeader f TYPE_byte ; 

(*strings*)
let f = newFunction (id_make "strlen") false in
let p = newParameter (id_make "_s") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in

ignore (p); 
endFunctionHeader f TYPE_int ; 

let f = newFunction (id_make "strcmp") false in
let p1 = newParameter (id_make "_s1") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in
let p2 = newParameter (id_make "_s2") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in

ignore (p1); ignore (p2); 
endFunctionHeader f TYPE_int ; 

let f = newFunction (id_make "strcpy") false in
let p1 = newParameter (id_make "_s1") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in
let p2 = newParameter (id_make "_s2") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in

ignore (p1); ignore (p2); 
endFunctionHeader f TYPE_proc ; 

let f = newFunction (id_make "strcat") false in
let p1 = newParameter (id_make "_s1") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in
let p2 = newParameter (id_make "_s2") (TYPE_array (TYPE_byte, 0)) PASS_BY_REFERENCE f false in

ignore (p1); ignore (p2); 
endFunctionHeader f TYPE_proc ; 

