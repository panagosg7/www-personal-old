open Printf
open Symbol
open Types
open Identifier 
open Quad
open PrintTools


let create_hashtable_ size init =
    let tbl = Hashtbl.create size in
    List.iter (fun (key, data) -> Hashtbl.add tbl key data) init;
    tbl


let reverse_op_table =
    create_hashtable_ 16 [ (EQ , DIFF ); (DIFF , EQ ); (LESS , EGREATER ); 
	(GREATER , ELESS ); (ELESS , GREATER ); (EGREATER , LESS ); ]

let print_temporary_f_l(n, _ , x, y, z ) = 
let f t q = 
	match t with 
	| Entry e -> 
		begin
		match e.entry_info with
		| ENTRY_temporary temp_info ->
			printf "%s: %d - %d\n" (id_name e.entry_id) temp_info.temporary_start_q temp_info.temporary_last_q; () 
		| _ -> () 
		end 
	| _ -> ()
in 
	f x n;
	f y n;
	f z n

(*metasximatismoi ipsilou epipedu*)
(*finds last use of temporaries*)
let find_last_p_q (n, _ , x, y, z ) = 
let f t q = 
	match t with 
	| Entry e | Index (Entry e)-> 
		begin
		match e.entry_info with
		| ENTRY_temporary temp_info ->
			begin
			if (temp_info.temporary_last_q<n) then 
					begin 
					temp_info.temporary_last_q <- q;	
				 	() 
					end 
			end
		| _ -> () 
		end 
	| _ -> ()

in 
	f x n;
	f y n;
	f z n


let rec copy_propagation list_ = 
begin
	match list_ with
	| [] -> [] 
	| [x] -> [x]
	| (n1, op, x, y, Entry e1)::(n2, GIVE, Entry e2, EMPTY, Entry i):: xs_ ->
		begin
		match e1.entry_info with
		| ENTRY_temporary temp_info  ->
			begin
			if ((id_name e1.entry_id) = (id_name e2.entry_id)) then
				begin
				if (temp_info.temporary_last_q <= n2) then
					begin
					temp_info.temporary_last_q <- (temp_info.temporary_last_q -2); (*if start >=n1 $x useless*)
					(n1, op, x, y, Entry i)::(n2, NOTHING, EMPTY, EMPTY, EMPTY):: (copy_propagation xs_)
					end
				else 
				(n1, op, x, y, Entry i)::(n2, GIVE, Entry e2, EMPTY, Entry i):: (copy_propagation xs_)
				end
			else
			(n1, op, x, y, Entry e1)::(n2, GIVE, Entry e2,  EMPTY, Entry i):: (copy_propagation xs_)
			end
		| _ -> (n1, op, x, y, Entry e1)::(n2, GIVE, Entry e2,  EMPTY, Entry i):: (copy_propagation xs_)
		end
	| x::xs -> x :: (copy_propagation xs)
end
	
let rec reverse_operant list_ =
begin
	match list_ with
	| [] -> [] 
	| [x] -> [x]
	| (n1, op, x, y, Label adr1)::(n2, JUMP, EMPTY, EMPTY, Label adr2):: xs_ ->  
		begin
			try
			if (adr1 = (n1 + 2)) & ( abs(n1-adr2) < 10) then 
				(n1, (Hashtbl.find reverse_op_table op), x, y, Label adr2)::(n2, NOTHING, EMPTY, EMPTY, EMPTY):: (reverse_operant xs_)
			else 	(n1, op, x, y, Label adr1)::(n2, JUMP, EMPTY, EMPTY, Label adr2):: (reverse_operant xs_)
			with Not_found -> (n1, op, x, y, Label adr1)::(n2, JUMP, EMPTY, EMPTY, Label adr2):: (reverse_operant xs_)
		end
	| x::xs -> x :: (reverse_operant xs)
end

let optimize_quads q =
let p = List.map find_last_p_q !q in ignore p; 
reverse_operant (copy_propagation !q)

