open Lexing
open Printf
open PrintTools
open BasicScope
open Format
open Error
open Identifier
open Types
open Symbol
open Final
open Quad

let main () =
let cin = 
 	if Array.length Sys.argv > 1
    then open_in Sys.argv.(1)
    else stdin
in
let lexbuf = Lexing.from_channel cin in
 let pos = lexbuf.lex_curr_p in
  try
	if Array.length Sys.argv > 1
	then lexbuf.lex_curr_p <- {pos with
		pos_lnum=pos.pos_lnum;
		pos_bol = pos.pos_cnum; 
		pos_fname = Sys.argv.(1); }
	else ();
	openBasicScope();
	openScope();
	Parser.program Lexer.token lexbuf;
	closeScope();
	closeScope();
	
	exit 0
  with 
	Parsing.Parse_error ->  
		message "%a There is a Parsing error.\n" print_position (position_point lexbuf.lex_curr_p);  exit 1
	| Error.Terminate -> exit 1
	| Exit -> exit 1
let _ = Printexc.print main ()
