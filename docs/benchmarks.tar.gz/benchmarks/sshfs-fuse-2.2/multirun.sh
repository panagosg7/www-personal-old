#/bin/bash
THREADS=32
TMP_FILE=tmp
TIMES=5

SERVER_DIR=eager:/
MOUNT_DIR1=mnt1
MOUNT_DIR2=mnt2

RD_TGT1=$MOUNT_DIR1/var/tmp/testfile2
RD_TGT2=$MOUNT_DIR2/var/tmp/testfile2
RD_DST=/dev/null
CORE=../coreutils-5.0


# vanilla verion
RESULTS=results1.txt
TMP_RESULTS=tmp_results.txt
rm -f $RESULTS 
rm -f $TMP_RESULTS 

if [ ! -d "$MOUNT_DIR1" ]; then
  mkdir $MOUNT_DIR1
fi
fusermount -u $MOUNT_DIR1

for ((i=1 ; i <= $THREADS  ; i*=2)) do
  sum1=0; sum2=0; sum3=0; sum4=0; sum5=0
  for ((j=1 ; j <= $TIMES  ; j+=1)) do
    printf "vanilla, $i thread(s) "
    ./sshfs $SERVER_DIR $MOUNT_DIR1
    sleep 1
    # run the patched version of cp
    /usr/bin/time -o tmp -f "%U %S %e" $CORE/src/cp $i $RD_TGT1 $RD_DST
    fusermount -u $MOUNT_DIR1
    sleep 1
    cat $TMP_FILE
    awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' $TMP_FILE >> $TMP_RESULTS
  done
  awk -v it=$i -v n="$TIMES" \
    '{sum1+= $2; sum2+=$3; sum3+=$4; sum4+=$5; sum5+=$6} \
     END{ print it " " sum1/n " " sum2/n " " sum3/n " " sum4/n " " sum5/n }' \
     $TMP_RESULTS >> $RESULTS
  echo "------------------------------------"  
  rm -f $TMP_RESULTS  
done

#modified version
RESULTS=results2.txt
TMP_RESULTS=tmp_results.txt
rm -f $RESULTS 
rm -f $TMP_RESULTS 

if [ ! -d "$MOUNT_DIR2" ]; then
  mkdir $MOUNT_DIR2
fi
fusermount -u $MOUNT_DIR2

for ((i=1 ; i <= $THREADS  ; i*=2)) do
  sum1=0; sum2=0; sum3=0; sum4=0; sum5=0
  for ((j=1 ; j <= $TIMES  ; j+=1)) do
    printf "modified, $i thread(s) "
    ./sshfs_mod $SERVER_DIR $MOUNT_DIR2
    sleep 1
    /usr/bin/time -o tmp -f "%U %S %e" $CORE/src/cp $i $RD_TGT2 $RD_DST
    fusermount -u $MOUNT_DIR2
    sleep 1
    cat $TMP_FILE
    awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' $TMP_FILE >> $TMP_RESULTS
  done
  awk -v it=$i -v n="$TIMES" \
    '{sum1+= $2; sum2+=$3; sum3+=$4; sum4+=$5; sum5+=$6} \
     END{ print it " " sum1/n " " sum2/n " " sum3/n " " sum4/n " " sum5/n }' \
     $TMP_RESULTS >> $RESULTS
  echo "------------------------------------"  
  rm -f $TMP_RESULTS  
done
