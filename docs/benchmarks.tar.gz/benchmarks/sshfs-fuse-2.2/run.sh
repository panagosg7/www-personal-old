#!/bin/bash

SERVER_DIR=eager:/
MOUNT_DIR=mnt

RD_TGT=$MOUNT_DIR/var/tmp/testfile2
RD_DST=/dev/null

THREADS=64
CORE=../coreutils-5.0
mkdir $MOUNT_DIR

rm -f results1.txt
echo -e "Testing READ.\nRunning ORIGINAL"
./sshfs $SERVER_DIR $MOUNT_DIR
printf "warming up "
/usr/bin/time -f "%U %S %e" $CORE/src/cp 1 $RD_TGT $RD_DST
fusermount -u $MOUNT_DIR

for ((i=1 ; i <= $THREADS ; i*=2)) do
  printf "vanilla, $i thread(s) "
  ./sshfs $SERVER_DIR $MOUNT_DIR
  sleep 1
  /usr/bin/time -o tmp -f "%U %S %e" $CORE/src/cp $i $RD_TGT $RD_DST
  fusermount -u $MOUNT_DIR
  sleep 1
  cat tmp
  awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' tmp >> results1.txt
  rm -f tmp
done

rm -f results2.txt
echo -e "Running ORIGINAL [DONE]\n\nRunning INSTRUMENTED"

./sshfs_mod $SERVER_DIR $MOUNT_DIR
printf "warming up "
/usr/bin/time -f "%U %S %e" $CORE/src/cp 1 $RD_TGT $RD_DST
fusermount -u $MOUNT_DIR
sleep 1

for ((i=1 ; i <= $THREADS ; i*=2)) do
  printf "modified, $i thread(s) "
  ./sshfs_mod $SERVER_DIR $MOUNT_DIR
  sleep 1
  /usr/bin/time -o tmp -f "%U %S %e" $CORE/src/cp $i $RD_TGT $RD_DST
  fusermount -u $MOUNT_DIR
  sleep 1
  cat tmp
  awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' tmp >> results2.txt
  rm -f tmp
done

echo -e "Running INSTRUMENTED [DONE]\n"

rmdir $MOUNT_DIR
