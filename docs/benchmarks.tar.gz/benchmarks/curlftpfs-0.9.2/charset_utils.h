#ifndef __CURLFTPFS_CHARSET_UTILS_H__
#define __CURLFTPFS_CHARSET_UTILS_H__

int convert_charsets(const char* from, const char* to, char** str);

#endif  /* __CURLFTPFS_CHARSET_UTILS_H__ */
