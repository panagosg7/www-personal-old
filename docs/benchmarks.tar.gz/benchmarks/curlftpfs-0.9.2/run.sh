#!/bin/bash

SERVER_DIR=ftp://ftp.ntua.gr/
MOUNT_DIR=ftp.ntua

RD_TGT=$MOUNT_DIR/pub/linux/debian/pool/main/t/texlive-doc/texlive-doc_2009.orig.tar.gz
RD_DST=/dev/null

THREADS=32
CORE=../coreutils-5.0

if [ ! -d $MOUNT_DIR ]; then
  mkdir $MOUNT_DIR
fi

fusermount -u $MOUNT_DIR
rm -f results1.txt

echo -e "Testing READ.\nRunning ORIGINAL"
./curlftpfs $SERVER_DIR $MOUNT_DIR
printf "warming up "
/usr/bin/time -f "%U %S %e" $CORE/src/cp 1 $RD_TGT $RD_DST

for ((i=1 ; i <= $THREADS ; i*=2)) do
  printf "vanilla, $i thread(s) "
  fusermount -u $MOUNT_DIR
  sleep 1
  ./curlftpfs $SERVER_DIR $MOUNT_DIR
  sleep 1
  /usr/bin/time -o tmp -f "%U %S %e" $CORE/src/cp $i $RD_TGT $RD_DST
  cat tmp
  awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' tmp >> results1.txt
  rm -f tmp
done
fusermount -u $MOUNT_DIR
sleep 2
echo -e "Running ORIGINAL [DONE]\n\n"

rm -f results2.txt
echo -e "Running INSTRUMENTED"

./curlftpfs_mod $SERVER_DIR $MOUNT_DIR
printf "warming up "
/usr/bin/time -f "%U %S %e" $CORE/src/cp 1 $RD_TGT $RD_DST

for ((i=1 ; i <= $THREADS ; i*=2)) do
  printf "modified, $i thread(s) "
  fusermount -u $MOUNT_DIR
  sleep 1
  ./curlftpfs_mod $SERVER_DIR $MOUNT_DIR
  sleep 1
  /usr/bin/time -o tmp -f "%U %S %e" $CORE/src/cp $i $RD_TGT $RD_DST
  cat tmp
  awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' tmp >> results2.txt
  rm -f tmp
done
fusermount -u $MOUNT_DIR
sleep 2
echo -e "Running INSTRUMENTED [DONE]\n\nPlotting:"

rmdir $MOUNT_DIR
 
