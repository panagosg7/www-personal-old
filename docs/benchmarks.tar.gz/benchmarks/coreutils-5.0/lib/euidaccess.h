#if ! HAVE_DECL_EUIDACCESS
int euidaccess (char const *file, int mode);
#endif
