#if !HAVE_CANONICALIZE_FILE_NAME
char *canonicalize_file_name (const char *);
#endif
