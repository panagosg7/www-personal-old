#include <config.h>
#include <stdio.h>
#include <sys/types.h>
#include "system.h"
#include "checksum.h"

int algorithm = ALG_MD5;
