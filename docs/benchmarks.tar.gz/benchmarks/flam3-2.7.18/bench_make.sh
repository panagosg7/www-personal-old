#!/bin/bash
./configure --disable-atomic-ops --prefix=$PWD && make clean all 
rm -r -f share
mkdir -p share/flam3
cp flam3-palettes.xml share/flam3/
cd bench_code
make 
cd ..

env sequence=test.flam3 template=vidres.flam3 nframes=10 ./flam3-genome > seq.flam3
