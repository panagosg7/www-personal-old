#!/bin/bash
THREADS=32
TMP_FILE=tmp1
FILE=../seq.flam3
TIMES=10


RESULTS=results1.txt
TMP_RESULTS=tmp_results.txt

rm -f $RESULTS 
rm -f $TMP_RESULTS 

for ((i=1 ; i <= $THREADS  ; i*=2)) do
  sum1=0; sum2=0; sum3=0; sum4=0; sum5=0
  mkdir -p OUT.vanilla/thread-$i
  for ((j=1 ; j <= $TIMES  ; j+=1)) do
    printf "vanilla, $i thread(s) "
    nthreads=$i /usr/bin/time -f "%U %S %e" -o $TMP_FILE ./flam3-render < $FILE > /dev/null 2> /dev/null
    cat $TMP_FILE
    awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' $TMP_FILE >> $TMP_RESULTS
    rm -f $TMP_FILE
    mkdir -p OUT.vanilla/thread-$i/run-$j
    mv 0*.png OUT.vanilla/thread-$i/run-$j
  done
  awk -v it=$i -v n="$TIMES" \
    '{sum1+= $2; sum2+=$3; sum3+=$4; sum4+=$5; sum5+=$6} \
     END{ print it " " sum1/n " " sum2/n " " sum3/n " " sum4/n " " sum5/n }' \
     $TMP_RESULTS >> $RESULTS
  echo "------------------------------------"  
  rm -f $TMP_RESULTS 
done

RESULTS=results2.txt
TMP_RESULTS=tmp_results.txt

rm -f $RESULTS 
rm -f $TMP_RESULTS 

for ((i=1 ; i <= $THREADS  ; i*=2)) do
  sum1=0; sum2=0; sum3=0; sum4=0; sum5=0
  mkdir -p OUT.modified/thread-$i
  for ((j=1 ; j <= $TIMES  ; j+=1)) do
    printf "modified, $i thread(s) "
    nthreads=$i /usr/bin/time -f "%U %S %e" -o $TMP_FILE ./flam3-render_mod < $FILE > /dev/null 2> /dev/null
    cat $TMP_FILE
    awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' $TMP_FILE >> $TMP_RESULTS
    rm -f $TMP_FILE
    mkdir -p OUT.modified/thread-$i/run-$j
    mv 0*.png OUT.modified/thread-$i/run-$j
  done
  awk -v it=$i -v n="$TIMES" \
    '{sum1+= $2; sum2+=$3; sum3+=$4; sum4+=$5; sum5+=$6} \
     END{ print it " " sum1/n " " sum2/n " " sum3/n " " sum4/n " " sum5/n }' \
     $TMP_RESULTS >> $RESULTS
  echo "------------------------------------"  
  rm -f $TMP_RESULTS
done

