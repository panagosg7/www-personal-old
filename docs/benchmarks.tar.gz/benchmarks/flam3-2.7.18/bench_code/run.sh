#!/bin/bash
THREADS=32
FILE=../seq.flam3

rm -f tmp results1.txt results2.txt

for ((i=1 ; i <= $THREADS ; i*=2)) do
  printf "vanilla $i threads "
  nthreads=$i /usr/bin/time -f "%U %S %e" -o tmp ./flam3-render < $FILE > /dev/null 2> /dev/null
  cat tmp
  awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' tmp >> results1.txt
  mkdir OUT-$i.vanilla/
  mv 0*.png OUT-$i.vanilla/
done

for ((i=1 ; i <= $THREADS ; i*=2)) do
  printf "modified $i threads "
  nthreads=$i /usr/bin/time -f "%U %S %e" -o tmp ./flam3-render_mod < $FILE > /dev/null 2> /dev/null
  cat tmp
  awk -v it=$i '{print it, " ", $3, $1+$2, " ", $0;}' tmp >> results2.txt
  mkdir OUT-$i.modified/
  mv 0*.png OUT-$i.modified/
# diff -rq OUT-$i.modified/ OUT-$i.vanilla && rm -fr OUT-$i.modified
done

#./plot.sh results1.txt results2.txt
