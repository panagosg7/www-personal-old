#!/bin/bash
./thrhttp_mod -p 8080
