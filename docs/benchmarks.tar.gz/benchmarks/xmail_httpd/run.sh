#!/bin/sh

if [ -z "$1" ] ; then
   echo "You need to specify the output file name.";
   exit -1;
else
   echo "Deleting output files $1 and tmp.";
   rm -f $1 tmp
fi 

if [ -z "$2" ] ; then
   echo "You need to specify the server name.";
   exit -1;
fi
#if [ "`hostname`" == "greedy" ]; then
#server=thread;
#else
#server=127.0.0.1;
#fi

echo "Server is: \"$server\"." 

server_up=`ssh $server "ps -ef | grep $2 | grep -v tcsh | grep -v grep | wc -l"`

if [ "$server_up" == "0" ]; then
   echo "Server $2 is down. Exiting";
   exit -1
else 
   echo "Server is $2 ..."   
fi 
#echo "Press any key to continue ..." 
#read

for ((i=10 ; i <= 2000 ; i*=2)) do
  c=$(( $i * 10 ))
  httperf-0.9.0/src/httperf --server=$server --port=8080 --num-conns=$c --rate=$i --uri=/pagefile > tmp
  y=`awk '/Reply rate/{print \$7}' tmp`
  x=`awk '/Request rate/{print \$3}' tmp`
  echo -e "$x $y" >> $1
  echo -e "`cat tmp`\n\n$x $y\n----------------------------\n"
done
