#!/bin/bash
./thrhttp -p 8080
