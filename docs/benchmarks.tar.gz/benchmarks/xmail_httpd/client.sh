server=greedy

if [ -z "$1" ] ; then
   echo "Missing http server host name" 
   exit -1
fi

server=$1
if [ ! -d "results" ]; then
  mkdir results
fi

last=`ls results | sort | tail -n 1`
next=`expr $last  + 1`
ssh $server  "pkill -9 thrhttp" 
ssh $server "pkill -9 thrhttp_mod"
echo "Results will be stored at results/$next"
echo "Start thrhttp and press any key to continue"
read
server=$server ./run.sh results1.txt thrhttp
echo "Start thrhttp_mod and press any key to continue"
read
server=$server ./run.sh results2.txt thrhttp_mod
mkdir -p results/$next
mv results*.txt results/$next
