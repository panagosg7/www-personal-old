--------------------------------------------------------------------------------
--																																						--
--											Author: Panagiotis Verkis															--				
--																																						--
--																																						--
--------------------------------------------------------------------------------


import Char
import IO
import List
import Data.Array.Unboxed

data Type  =  Tvar Int | Tfun Type Type | Terror               deriving Eq
data Expr  =  Evar String | Eabs String Expr | Eapp Expr Expr  deriving Eq

-- Pretty printing of expressions

always = True    -- False omits parentheses whenever possible

instance Show Expr where
  showsPrec p (Evar x) = (x ++)
  showsPrec p (Eabs x e) =
    showParen (always || p > 0) ((("\\" ++ x ++ ". ") ++) . showsPrec 0 e)
  showsPrec p (Eapp e1 e2) =
    showParen (always || p > 1) (showsPrec 1 e1 . (" " ++) . showsPrec 2 e2)

-- Parsing of expressions

instance Read Expr where
  readsPrec _ s =
    readParen True (\s ->
      [(Eabs x e, r)    |  ("\\", t1)  <-  lex s,
                           (x, t2)     <-  lex t1, isVar x,
                           (".", t3)   <-  lex t2,
                           (e, r)      <-  readsPrec 0 t3] ++
      [(Eapp e1 e2, r)  |  (e1, t)     <-  readsPrec 0 s,
                           (e2, r)     <-  readsPrec 0 t]) s ++
    [(Evar x, r) | (x, r) <- lex s, isVar x]
      where isVar x = isAlpha (head x) && all isAlphaNum x

-- Pretty printing of types

instance Show Type where
  showsPrec p (Tvar alpha) = ("@" ++) . showsPrec 0 alpha
  showsPrec p (Tfun sigma tau) = showParen (p > 0) 
  	(showsPrec 1 sigma . (" -> " ++) . showsPrec 0 tau)
  showsPrec p (_) = ("type error" ++)  

-- Main program
readOne  =  do  s <- getLine
                return (read s :: Expr)

count n m  =  sequence $ take n $ repeat m


-- Check environment
is_in_env:: String -> [(String,Type)] -> Int
is_in_env a [] = -1
is_in_env str ((s, Tvar n):xs) = if (str==s) then n else is_in_env str xs

getType (t,l,n) = t
getCons (t,l,n) = l
getNum (t,l,n) = n

-- Find type and constraints
find_type_cons:: [(String,Type)] -> Int ->  Expr -> (Type, [(Type,Type)],Int)

find_type_cons env n (Evar s) =  let t = is_in_env s env in
                                 if (t<0) then (Terror,[],n) else (Tvar t,[],n)

find_type_cons env n (Eabs s e) = (Tfun a t, c,m+1)
    where env1 =  [(s,Tvar n)] ++ env
          a = Tvar n --getType (find_type_cons env1 n (Evar s))
          tcm = find_type_cons env1 (n+1) e
          t = getType tcm
          c = getCons tcm
          m = getNum tcm
          
find_type_cons env n  (Eapp e1 e2) = (alpha, c, m2)
    where tc1 = find_type_cons env (n+1) e1
          m1 = getNum tc1            ------------
          tc2 = find_type_cons env m1 e2
          m2 = getNum tc2            ------------
          sigma = getType (tc1)          
          tau = getType (tc2)
          alpha = Tvar n
          c = (getCons tc1) ++ (getCons tc2) ++ [(sigma, Tfun tau alpha)]
  
-- Unify Function : Constraints -> Substitutions
appears_not_in:: Type -> Type -> Bool
appears_not_in t1 t2 =  case t2 of 
                          Tvar n -> if (t1 == Tvar n) then False else True
                          Tfun s1 s2 -> if (t1==s1 || t1==s2) then False else
                                          (appears_not_in t1 s1) && (appears_not_in t1 s2)
                          
-- Type Substitution
sub1:: Type -> Type -> Type -> Type
sub1 t1 t2 (Tvar n) = if (t1 == Tvar n) then t2 else Tvar n 
sub1 t1 t2 (Tfun s1 s2) = Tfun (sub1 t1 t2 s1) (sub1 t1 t2 s2)
sub1 t1 t2 Terror = Terror
                          
sub:: Type -> Type -> (Type,Type) -> (Type,Type)
sub t1 t2 (s1,s2) = (sub1 t1 t2 s1, sub1 t1 t2 s2)


-- Unify
unify:: [(Type,Type)] -> [(Type,Type)]
unify [] = []
unify ((tau1,tau2):xs) = if (tau1 == tau2) then unify xs else
                           case (tau1, tau2, appears_not_in tau1 tau2, appears_not_in tau2 tau1) of
                             (Tvar a,_, True, _)              ->  unify (map (sub tau1 tau2) xs) ++ [(tau1,tau2)]
                             (_,Tvar a,_,True)                ->  unify (map (sub tau2 tau1) xs) ++ [(tau2,tau1)] 
                             (Tfun t11 t12, Tfun t21 t22,_,_) ->  unify (xs ++ [(t11,t21),(t12,t22)])
                             (_,_,_,_)                        -> [(Terror,Terror)]                                     

-- Final Substitution
--fsub:: Type -> Constraints -> Type
fsub2::Type -> Type -> [(Type,Type)] -> [(Type,Type)]
fsub2 t1 t2 [] = []
fsub2 t1 t2 ((ct1,ct2):cs) = ((sub1 t1 t2 ct1, sub1 t1 t2 ct2):(fsub2 t1 t2 cs))

fsub1::Type -> [(Type,Type)] -> Type
fsub1 t [] = t
fsub1 t ((Terror,_):ts) = Terror
fsub1 t ((_,Terror):ts) = Terror
fsub1 t ((t1,t2):ts) =  fsub1 (sub1 t1 t2 t) (fsub2 t1 t2 ts)

fsub::[Type] -> [[(Type,Type)]] -> [Type]
fsub [] _ = []
fsub (t:ts) (c:cs) = ((fsub1 t c):(fsub ts cs))


-- Lexicographic Sort
max_index:: Int -> Type -> Int
max_index c (Tvar n)  = max c n
max_index c (Tfun t1 t2)  = max (max_index c t1) (max_index c t2)
max_index c Terror  = -1

fill_array:: Int -> UArray (Int) Int -> Type -> (UArray (Int) Int,Int)
fill_array c sa (Tvar n)  = if (sa!(n)<0) then (sa // [(n,c)], c+1) else (sa,c)
fill_array c sa (Tfun t1 t2)  = 
    let (sa1,c1) = fill_array c sa t1 in 
      fill_array c1 sa1 t2
fill_array c sa Terror  = (sa,c)

rename:: UArray (Int) Int -> Type -> Type
rename a (Tvar n) = Tvar (a!(n))
rename a (Tfun t1 t2) = Tfun (rename a t1) (rename a t2)
rename a Terror = Terror

lexic:: Type  -> Type
lexic t = 
  let mi = max_index 0 t in
  let (a,_) = fill_array 0 (array (0,mi) [(i,-1)| i <- [0..mi]]) t in
    rename a t


main     =  do  n <- readLn
                x <- count n readOne
--                mapM_ print x  
                tc <- return( map (find_type_cons [] 0) x)::IO [(Type, [(Type,Type)], Int )]
                t <- return(map getType tc)
 --               mapM_ print t
                c <- return(map getCons tc)
 --               mapM_ print c 

                
--final constraints
                fc <- return(map unify c)
                fs <- return (fsub t fc) 
                res <- return(map lexic fs)               

{-
                putStr "final constraints: "
                mapM_ print fc
                putStr "final_result: "
                mapM_ print fs                
                putStr "final result: "
-}
                mapM_ print res
                
                

              
